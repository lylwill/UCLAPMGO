"use strict"

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var PlayerSchema = new Schema({
    id: {type: String},
    pokemons: {type: Array},
    number: {type: Number, default: 0},
    long: {type: Number},
    lat: {type: Number}
});

PlayerSchema.pre('save',function(next){
    next();
});

module.exports=mongoose.model('Player',PlayerSchema);