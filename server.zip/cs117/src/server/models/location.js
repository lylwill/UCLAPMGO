"use strict"

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var LocationSchema = new Schema({
    long: {type: Number, min: -180, max: 180},
    lat: {type: Number, min: -90, max: 90},
    pokemon: {type: String}
});

LocationSchema.pre('save',function(next){
    next();
});

module.exports=mongoose.model('Location',LocationSchema);
