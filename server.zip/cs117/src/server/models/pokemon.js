"use strict"

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var PokemonSchema = new Schema({
    name: {type: String},
    long: {type: Number, min: -180, max: 180},
    lat: {type: Number, min: -90, max: 90}
});

PokemonSchema.pre('save',function(next){
    next();
});

module.exports=mongoose.model('Pokemon',PokemonSchema);