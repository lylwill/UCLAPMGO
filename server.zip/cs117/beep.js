var io = require('socket.io')({
    transports: ['websocket'],
});

io.attach(8080);
var id = 1;
var counter = 0;
var starttime = 0;
console.log('start');
io.on('connection', function(socket){
   console.log('on connection');
   starttime = Date.now()/1000;
    socket.on('new player', function(msg){
        // console.log('message: ' + JSON.stringify(msg));
        socket.emit('get id 0', {'id': id});
        id = id+1;
        counter = counter+1;
        console.log('counter:');
        socket.emit('update counter',{'counter':counter});
    });
    socket.on('counter update',function(msg){
        console.log('get')
        socket.emit('update counter',{'counter':counter});
    });
    socket.on('timer',function(msg){
        var curr = Date.now()/1000;
        socket.emit('clock',{'time':10-(curr-starttime)});
    });
    // socket.on('update player location',function(msg){
    //     socket.emit('update neighbours',{1:[3,4],9:[5,6]})
    // });
    //
    // socket.on('initialize',function(msg){
    //     socket.emit('initialized',{'110,110':'eeve'})
    // });
    //
    // socket.on('caught',function(msg){
    //     console.log('message: ' + JSON.stringify(msg));
    //     socket.emit('update pokemon location',{'110,110':'pikachu'})
    // });
    //
    // socket.on('battle',function(msg){
    //     console.log('message: ' + JSON.stringify(msg));
    //     socket.emit('oponent info',{'len':3,'speices':['pikachu','eeve','meetwo'] })
    // });
})
