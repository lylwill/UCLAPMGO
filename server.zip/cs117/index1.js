'use strict';

// Get all modules needed
var express         = require('express'),
    http             = require('http'),
    bodyParser      = require('body-parser'),
    logger          = require('logger'),
    mongoose        = require('mongoose'),
    io              = require('socket.io'),
    path            = require('path'),
    methodOverride = require('method-override'),
    Player = require('./src/server/models/player'),
    Location = require('./src/server/models/location'),
    Pokemon = require('./src/server/models/pokemon');

// MongoDB set up
var uristring = 'mongodb://csm117:fall2017@ds040877.mlab.com:40877/csm117db';
var options = {
    useMongoClient: true
};
mongoose.connect(uristring,options, function (err, res) {
    if (err) {
        console.log ('ERROR connecting to: ' + uristring + '. ' + err);
    } else {
        console.log ('Succeeded connected to: ' + uristring);
    }
});

// Set up
var app = express();
var server = http.Server(app);
var ioServer = io(server);

app.set('port', process.env.PORT || 8080);
app.use(express.static(__dirname + './public'));
app.use(app.router);
app.use(bodyParser.json({}));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(methodOverride());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

var playerCount = 0;

// Initialize the map with pokemons at random locations within range
var minLong = -118.43799,
    maxLong = -118.451852,
    minLat = 34.066155,
    maxLat = 34.077237;

var pokemonTypes = ["Larvitar","Bulbasaur","Charmander","Eevee","Pikachu","Squirtle","Charizard","Dragonite","Entei","Greninja","Ho-Oh","Mewtwo","Slowpoke","Raikou","Snorlax","Suicune"]

var initialPokemons = [];

for (var i = 0; i < 16; i++) {
    var newLong = (Math.random() * (maxLong - minLong) + minLong).toFixed(5),
        newLat = (Math.random() * (maxLat - minLat) + minLat).toFixed(5),
        newPokemon = pokemonTypes[i];

    initialPokemons.push({name: newPokemon, long: newLong, lat: newLat});
}

//locations.forEach(function(location){
//    var newLocation = new Location(location);
//    newLocation.save(function(err){
//        if(err){
//            console.log('Error: ' + err);
//        }
//        else{
//            console.log('New Location: ' + location);
//        }
//    });
//});

Pokemon.remove({}, function(err) {
    if (err) {
        console.log(err)
    } else {
        console.log('success');
    }
});

Player.remove({}, function(err) {
    if (err) {
        console.log(err)
    } else {
        console.log('success');
    }
});

initialPokemons.forEach(function(pokemon){
    var newPokemon = new Pokemon(pokemon);
    newPokemon.save(function(err){
        if(err) {
            console.log('Error: ' + err);
        }
    });
});


// ID stack
var ids = [1, 2, 3];
var startTime = 0;

// Connect to a client socket
ioServer.on('connection', function(client){
    console.log("on connection");
    Player.findOne({'id': 1}, function(err, player){
        if (player == null) {
            startTime = Date.now() / 1000;
        }
    });

    client.on('timer', function(data){
        console.log('on timer');
        var currTime = Date.now() / 1000;
        ioServer.emit('clock', {'time': 10 - (currTime - startTime)});
        console.log('clock sent');
    });

    client.on('new player', function(){
        var id = ids.shift();
        Player.findOne({'id': id},function(err, player){
            if(player == null){
                // Player not found in DB; create a new entry
                var newPlayer = new Player({
                    'id': id
                });
                console.log(newPlayer);
                playerCount++;
                newPlayer.save(function(err){
                    if(err){
                        console.log('Error: ' + err);
                    }
                    else{
                        console.log('New Player: ' + id);
                    }
                });
            }
            else{
                // Player found in DB
                player.save(function(err){
                    if(err){
                        console.log('Error: ' + err);
                    }
                    else {
                        console.log('Player found in DB');
                    }
                })
            }
        });

        ioServer.emit('get id 0', {'id': id});
    });

    client.on('quit game', function(data){
        playerCount--;
        console.log('here');
        var id = data.id;
        console.log(id);

        Player.findOneAndRemove({'id': id}, function(err, player){
            ids.push(id);
            if(err){
                console.log('Error: ' + err);
            }
            else {
                console.log('Player quit: ' + id);
            }
        });
    });

    client.on('counter update', function(data){
        ioServer.emit('update counter', {'counter': playerCount});
    });

    client.on('initialize', function() {
        Pokemon.find({}, function(err, pokemons) {
            var pokemonMap = [];
            if(err){
                console.log('Error: ' + err);
            }
            else {
                console.log('Initialized.');
            }
            pokemons.forEach(function(pokemon) {
                pokemonMap.push(pokemon);
            });
            // console.log(pokemonMap);
            ioServer.emit('initialized', {'map': pokemonMap});
            ioServer.emit('status', {'status': true});
            console.log('Finished init');
        });

    });

    client.on('update player info', function(data){
        Player.findOne({'id': data.id}, function(err, player){
            if (player != null) {
                console.log(player);
                player.long = data.long;
                player.lat = data.lat;
                player.pokemons = data.pokemons;
                player.number = data.pokemons.length;
                player.save(function(err){
                    if(err){
                        console.log('Error: ' + err);
                    }
                    else {
                        //console.log('Player info updated');
                    }
                })
            }
        });
    });

    client.on('update neighbour location', function(data){
        var playerMap = {};
        Player.find({}, function(err, players){
            players.forEach(function(player) {
                playerMap[player.id] = {long: player.long, lat: player.lat};
            });
            ioServer.emit('update neighbours ' + data.id, playerMap);
        });
    });

    client.on('caught', function(data){
        console.log("on caught");
        var pokemonName = data.pokemon;
        console.log(pokemonName);

        var newLong = (Math.random() * (maxLong - minLong) + minLong);
        var newLat = (Math.random() * (maxLat - minLat) + minLat);

        Pokemon.findOne({'name': pokemonName}, function(err, pokemon) {
            if (pokemon != null) {
                pokemon.long = newLong;
                pokemon.lat = newLat;
                pokemon.save(function(err) {
                    if (err) {
                        console.log('Error: ' + err);
                    }
                    else {
                        console.log('Caught success');
                    }
                })
            }
        });
        // console.log({'name': pokemonName, 'long': newLong, 'lat': newLat});
        ioServer.emit('update pokemon location', {'name': pokemonName, 'long': newLong, 'lat': newLat});
    });

    client.on('battle', function(data){
        var opponentId = data.opponentId,
            numPokemons = 0,
            pokemonList = [];

        Player.findOne({'id': opponentId}, function(err, opponent){
            if (opponent != null) {
                numPokemons = opponent.number;
                pokemonList = opponent.pokemons;
                ioServer.emit('opponent info ' + opponentId, {'number': numPokemons, 'list': pokemonList});
            }
        });
    });

    client.on('rank', function(data){
        var id = data.id,
            rank = 0;
        Player.find().sort({ number: 'desc' }).exec(function(err, rankings) {
            if (err) {
                console.log('Error: ' + err);
            }
            else {
                console.log(rankings);
                for (var i = 0; i < rankings.length; i++) {
                    if (rankings[i].id == id) {
                        rank = i + 1;
                        console.log(rank);
                        break;
                    }
                }
                ioServer.emit('ranking ' + id, {'rank': rank});
            }
        });
    });

})

app.get('/', function (req, res) {
    //res.render('index');
    res.sendfile('./public/index.html');
});


// Search for a person's history
//app.get('/player/:id', function(req, res){
//    var playerid = req.params.id;
//    Player.findOne({'playerid': playerid}, function(err, player){
//        if(err){
//            res.status(404).send('Player not found.');
//        }
//        else{
//            var info = {
//                'first_name': player.first_name,
//                'last_name': player.last_name,
//                'current_room': player.current_room,
//                'entry_time': player.entry_time
//            };
//            res.status(200).send(info);
//        }
//    });
//});

// Start listening
server.listen(process.env.PORT || 8080, function () {
    console.log('App listening on ' + server.address().port);
});