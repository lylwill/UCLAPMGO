var io = require('socket.io-client');
var socket = io.connect('http://131.179.61.195:8080/', {reconnect: true});

// Add a connect listener
socket.on('connection', function (socket) {
    console.log('Connected!');
});
socket.emit('new player', {'id':8});