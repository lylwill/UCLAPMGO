'use strict';

var execAjax = function() {
    var username = $("#username").val();
    var password = $("#password").val();
    //$.post(url,data).chainingMethod()
    $.post("/v1/session",{username:username,password:password}).success(
        function(){
            $('#logform').fadeOut(function () {
                window.location.href = "/map.html";
            });
        }
    ).fail(
        function(err){
            console.log(err);
        }
    )

};